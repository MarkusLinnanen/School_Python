INSERT INTO flightwreck.enemy (`type`,enemy_count,hp_needed) VALUES
	 ('abandoned',0,0),
	 ('boss',5,75),
	 ('heavy',10,50),
	 ('light',15,45);

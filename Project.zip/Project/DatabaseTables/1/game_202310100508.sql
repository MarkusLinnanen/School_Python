INSERT INTO flightwreck.game (id,location,hp,gas,user_name,difficulty,xp,powerup,`time`) VALUES
	 (0,'NE-0001',100,2400,'JOHN','0',0,'NULL','00:00:00'),
	 (1,'PL-0073',100,2400,'David','0',0,'NULL','00:00:00');
